insert into login values ('admin','admin','Administrator');
insert into login values ('user1','12345','Teacher');
insert into login values ('user2','12345','Teacher');
insert into login values ('user3','12345','Teacher');
insert into login values ('ruth','rute','Teacher');

insert into teacher values (1,'Kebede','user1');
insert into teacher values (2,'Bekele','user2');
insert into teacher values (3,'Chaltu','user3');
insert into teacher values (4,'Ruth','ruth');


insert into subject values(101,'Data Structures');
insert into subject values(102,'Operating Systems');
insert into subject values(103,'Database Management');
insert into subject values(104,'Unix Programming');
insert into subject values(105,'System Softwares');
insert into subject values(106,'Distributed System Programming');
insert into subject values(107,'Wireless Networks');



insert into teaches values(1,101);
insert into teaches values(1,103);
insert into teaches values(2,102);
insert into teaches values(2,103);
insert into teaches values(3,101);
insert into teaches values(4,102);
insert into teaches values(5,107);
insert into teaches values(6,106);
insert into teaches values(5,105);
insert into teaches values(6,104);




insert into student values(1,'Getahun Heramo','Computer','Third',101);
insert into student values(1,'Getahun Heramo','Computer','Third',102);
insert into student values(2,'Chala Dabala','Computer','Fourth',102);
insert into student values(2,'Chala Dabala','Computer','Fourth',103);



insert into attendence values('2018-10-10', 'Present',1,101);
insert into attendence values('2018-10-11', 'Present',1,101);
insert into attendence values('2018-10-12', 'Present',1,101);
insert into attendence values('2018-10-13', 'Present',1,101);
insert into attendence values('2018-10-14', 'Present',1,101);
insert into attendence values('2018-10-10', 'Present',1,102);
insert into attendence values('2018-10-11', 'Present',1,102);
insert into attendence values('2018-10-12', 'Absent',1,102);
insert into attendence values('2018-10-13', 'Absent',1,102);
insert into attendence values('2018-10-14', 'Absent',1,102);
insert into attendence values('2018-10-10', 'Present',2,102);
insert into attendence values('2018-10-11', 'Present',2,102);
insert into attendence values('2018-10-12', 'Present',2,102);
insert into attendence values('2018-10-13', 'Present',2,102);
insert into attendence values('2018-10-14', 'Present',2,102);