For the application you need to consider the following steps
The application is Desktop application (simple dbms).
Language: Java
Database: mysql
database name: mydb

It is Attendance Managament system for daily bases.


You need to use Netbeans editor
You need to connect Netbeans with Mysql
For the mysql you can use wamp integrated mysql because it has no password.
I recommend you to use wamp integrated mysql because it has requirement of password which none with root user.
other wise if you have standalone mysql server you can use with username and password